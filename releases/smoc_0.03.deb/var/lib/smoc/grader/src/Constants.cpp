#include "Constants.h"

using namespace std;

string Constants::CONFIG_FILE = "config.grader";

