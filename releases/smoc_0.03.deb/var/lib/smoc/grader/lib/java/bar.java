class bar {
	public static void boza() {
		System.out.println("Java e boza");
	}
}
